/**
 * Siraf Jasayi Portfolio - Official Apple WWDC25 Liquid Glass Interaction Engine
 * Features:
 * - Internal Specular Illumination on Touch & Click
 * - Gel-like Elastic Press Animation (scale(0.96))
 * - Real-time Specular Glare & Cursor Spotlight Tracking
 * - Scroll Edge Progressive Dissolution Header & Progress Bar
 * - Adaptive Tinting System: Apple Liquid Glass Dark / Ceramic Light Mode
 * - Project Tender Modals, Skills Segmented Filter, Typing Text, Clipboard & Form
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  /* ==========================================================================
     1. Adaptive Tinting: Apple Dark / Light Mode Switcher
     ========================================================================== */
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const htmlRoot = document.documentElement;

  // Initialize theme from localStorage or system preference
  const savedTheme = localStorage.getItem('siraf_portfolio_theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initialTheme = savedTheme ? savedTheme : (systemPrefersDark ? 'dark' : 'dark');

  htmlRoot.setAttribute('data-theme', initialTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = htmlRoot.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      
      htmlRoot.setAttribute('data-theme', newTheme);
      localStorage.setItem('siraf_portfolio_theme', newTheme);
      
      showToast(`Switched to Apple ${newTheme === 'dark' ? 'Obsidian Dark' : 'Ceramic Light'} Mode`);
    });
  }

  /* ==========================================================================
     2. Interactive Fluidity: Internal Specular Illumination on Touch / Click
     ========================================================================== */
  function createSpecularBloom(e, container) {
    const rect = container.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 1.5;
    
    // Calculate relative coordinate
    const clientX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : rect.left + rect.width / 2);
    const clientY = e.clientY || (e.touches && e.touches[0] ? e.touches[0].clientY : rect.top + rect.height / 2);
    
    const x = clientX - rect.left - size / 2;
    const y = clientY - rect.top - size / 2;

    const bloom = document.createElement('span');
    bloom.classList.add('wwdc-specular-bloom');
    bloom.style.width = `${size}px`;
    bloom.style.height = `${size}px`;
    bloom.style.left = `${x}px`;
    bloom.style.top = `${y}px`;

    container.appendChild(bloom);

    // Gel press trigger
    container.classList.add('active-gel-press');

    setTimeout(() => {
      container.classList.remove('active-gel-press');
    }, 220);

    setTimeout(() => {
      if (bloom.parentElement) {
        bloom.remove();
      }
    }, 750);
  }

  // Bind to all elements with class .wwdc-touchable
  const touchableElements = document.querySelectorAll('.wwdc-touchable');
  touchableElements.forEach(el => {
    el.addEventListener('pointerdown', (e) => {
      // Don't intercept clicks inside inputs or close buttons
      if (e.target.closest('input, textarea, select')) return;
      createSpecularBloom(e, el);
    });
  });

  /* ==========================================================================
     3. Card Glare & Specular Spotlight Cursor Tracking
     ========================================================================== */
  const cards = document.querySelectorAll('.wwdc-glass-card');
  const spotlight = document.getElementById('cursorSpotlight');

  // Spotlight follows mouse
  window.addEventListener('pointermove', (e) => {
    if (spotlight) {
      spotlight.style.left = `${e.clientX}px`;
      spotlight.style.top = `${e.clientY}px`;
    }
  });

  // Calculate local coordinates for card glare reflections
  cards.forEach(card => {
    card.addEventListener('pointermove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);
    });
  });

  /* ==========================================================================
     4. Scroll Edge Dissolution Header & Scroll Progress
     ========================================================================== */
  const header = document.getElementById('header');
  const scrollProgress = document.getElementById('scrollProgress');
  const backToTopBtn = document.getElementById('backToTop');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    
    // Progress bar width
    if (scrollProgress && docHeight > 0) {
      const progressPercent = (scrollY / docHeight) * 100;
      scrollProgress.style.width = `${progressPercent}%`;
    }

    // Header scroll edge dissolution state
    if (header) {
      if (scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    // Back to top visibility
    if (backToTopBtn) {
      if (scrollY > 450) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }
  }, { passive: true });

  /* ==========================================================================
     5. Dynamic Typing Subtitle Effect
     ========================================================================== */
  const typedTextEl = document.getElementById('typedText');
  if (typedTextEl) {
    const roles = [
      'Quantity Surveying (Civil & MEP)',
      'Digital Quantity Take-Offs',
      'PlanSwift & AutoCAD Estimation',
      'Standard BOQ Preparation',
      'Tender Pricing & Rate Build-Up'
    ];
    let roleIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 70;

    function typeEffect() {
      const currentRole = roles[roleIndex];

      if (isDeleting) {
        typedTextEl.textContent = currentRole.substring(0, charIndex - 1);
        charIndex--;
        typingSpeed = 35;
      } else {
        typedTextEl.textContent = currentRole.substring(0, charIndex + 1);
        charIndex++;
        typingSpeed = 75;
      }

      if (!isDeleting && charIndex === currentRole.length) {
        isDeleting = true;
        typingSpeed = 1800; // Pause at end of text
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        roleIndex = (roleIndex + 1) % roles.length;
        typingSpeed = 400; // Pause before typing new text
      }

      setTimeout(typeEffect, typingSpeed);
    }

    setTimeout(typeEffect, 600);
  }

  /* ==========================================================================
     6. Skills Segmented Filter (WWDC25 Segmented Control)
     ========================================================================== */
  const skillTabs = document.querySelectorAll('.skill-tab-btn');
  const skillCards = document.querySelectorAll('.skill-card');

  skillTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      skillTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const filter = tab.getAttribute('data-filter');

      skillCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filter === 'all' || category === filter) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, 40);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translateY(15px)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 200);
        }
      });
    });
  });

  /* ==========================================================================
     7. WWDC25 Key Projects Modal Popup
     ========================================================================== */
  const projectModal = document.getElementById('projectModal');
  const modalBody = document.getElementById('modalBody');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  const projectCards = document.querySelectorAll('.project-card');

  const projectDetails = {
    autoboulevard: {
      tag: 'Commercial Tender Package &bull; Qatar',
      title: 'Auto Boulevard Showroom & Service Facility',
      desc: 'Extensive tender quantification and pricing for a flagship automotive showroom in Qatar encompassing showroom galleries, luxury VIP reception areas, executive administration suites, and high-tech vehicle service workshops.',
      sections: [
        {
          heading: 'Civil & Structural Take-Off Scope',
          items: [
            'Structural steel framing, portal frames, trusses, purlins, and specialized tensile canopy members.',
            'Deep pad foundation, reinforced concrete grade beams, and heavy-duty slab-on-grade floors.',
            'Architectural double-glazed curtain wall facades, composite aluminum cladding panels, and acoustic ceilings.'
          ]
        },
        {
          heading: 'MEP Quantification Scope',
          items: [
            'Central chilled water HVAC distribution, ductwork insulation, VAV boxes, and specialized air extraction systems.',
            'High-voltage main distribution panels, busbar trunking, architectural LED linear illumination, and emergency UPS backup.',
            'Fire suppression systems including wet pipe sprinklers, deluge systems, fire hose reels, and smoke extractors.'
          ]
        },
        {
          heading: 'Estimating Software & Deliverables',
          items: [
            'Digital on-screen take-off models constructed using PlanSwift & AutoCAD.',
            'Comprehensive BOQ schedules formatted in compliance with Standard Method of Measurement (POMI / NRM).',
            'Subcontractor RFQ comparative analysis sheets and material supplier price rate build-ups.'
          ]
        }
      ]
    },
    majlis: {
      tag: 'Cultural & Architectural &bull; Qatar',
      title: 'Majlis & Masjid Building Complex',
      desc: 'High-profile traditional and contemporary Majlis compound with an adjoining community Masjid featuring intricate Islamic architectural ornamentation, dome engineering, heavy foundations, and specialized acoustic lighting.',
      sections: [
        {
          heading: 'Ornate Architectural & Civil Scope',
          items: [
            'Substructure earthworks, reinforced raft foundation, perimeter retaining walls, and waterproof tanking systems.',
            'Custom hand-carved GRC (Glass Reinforced Concrete) exterior arches, Mashrabiya decorative screens, and Minaret masonry.',
            'Premium Italian & Omani marble floor finishes, ornamental acoustic gypsum plastering, and gold-leaf calligraphy trims.'
          ]
        },
        {
          heading: 'Specialized MEP & Audio Scope',
          items: [
            'Low-noise ducted split and VRF air-conditioning systems designed for high-occupancy assembly halls.',
            'Custom prayer hall chandelier suspensions, perimeter LED architectural lighting, and external facade floodlights.',
            'Integrated high-fidelity public address (PA) sound distribution and multi-zone acoustic management.'
          ]
        },
        {
          heading: 'Estimating Deliverables',
          items: [
            'Specialist craftsman labor estimation, custom marble cut-list calculations, and dome structural take-offs in PlanSwift.',
            'Itemized tender Bills of Quantities and subcontractor variation evaluation models.'
          ]
        }
      ]
    },
    labs: {
      tag: 'Healthcare & Science &bull; Qatar',
      title: 'Environmental & Radiation Laboratories',
      desc: 'State-of-the-art diagnostic and environmental testing laboratory complex demanding rigorous precision, radiation-proof lead shielding, clean-room environments, and specialized gas delivery pipelines.',
      sections: [
        {
          heading: 'Specialist Shielding & Cleanroom Finishes',
          items: [
            'Lead-lined gypsum partition walling, heavy-density concrete radiation bunkers, and radiation-shielded motorized lead doors.',
            'Seamless anti-static, chemical-resistant epoxy flooring and antimicrobial sterile wall coatings.',
            'Laboratory fume hoods, laminar air flow cabinets, and chemical storage safety enclosures.'
          ]
        },
        {
          heading: 'Critical MEP & Gas Distribution',
          items: [
            'Positive/negative pressure differential HVAC cascades with HEPA & ULPA filtration stages.',
            'Medical and laboratory gases (Nitrogen, Helium, Compressed Air, Vacuum) stainless steel piping.',
            'Dual-redundant emergency standby power generators, automatic transfer switches (ATS), and isolated grounding.'
          ]
        },
        {
          heading: 'Estimating Deliverables',
          items: [
            'Strict tolerance material take-offs with zero defect margins using PlanSwift and custom Excel matrix templates.',
            'Comprehensive risk-adjusted cost benchmarking for specialized imported laboratory equipment.'
          ]
        }
      ]
    },
    residential: {
      tag: 'Residential & Housing &bull; Qatar & Sri Lanka',
      title: 'Multi-Unit Residential Developments',
      desc: 'Multi-unit contemporary residential compounds and housing projects featuring reinforced concrete frames, luxury internal fit-outs, full domestic MEP installations, and landscaped external infrastructure.',
      sections: [
        {
          heading: 'Civil & Architectural Quantity Scope',
          items: [
            'Site clearance, mass excavation, isolated column footings, tie beams, and suspended hollow-block slabs.',
            'Blockwork masonry, cement plastering, waterproofing membranes for wet areas, and porcelain floor tiling.',
            'Solid hardwood timber doors, thermal-break aluminum windows, and perimeter boundary wall masonry.'
          ]
        },
        {
          heading: 'Residential MEP Scope',
          items: [
            'Internal water supply (PPR / PEX piping), solar water heating, booster pumps, and drainage soil/waste stacks.',
            'Final circuit electrical distribution, modular switches, data/TV outlets, and smart home automation provisions.'
          ]
        },
        {
          heading: 'Estimating Deliverables',
          items: [
            'Standard Bills of Quantities (BOQ) with itemized trade schedules prepared in PlanSwift & MS Excel.',
            'Subcontractor bid comparison and monthly Interim Payment Certificate (IPC) validation.'
          ]
        }
      ]
    }
  };

  function openModal(projectId) {
    const data = projectDetails[projectId];
    if (!data || !modalBody || !projectModal) return;

    let sectionsHtml = '';
    data.sections.forEach(sec => {
      let listItems = '';
      sec.items.forEach(item => {
        listItems += `<li><i class="fa-solid fa-circle-check"></i><span>${item}</span></li>`;
      });

      sectionsHtml += `
        <h4 class="modal-section-title">${sec.heading}</h4>
        <ul class="modal-list">${listItems}</ul>
      `;
    });

    modalBody.innerHTML = `
      <span class="modal-header-tag">${data.tag}</span>
      <h3 class="modal-title">${data.title}</h3>
      <p class="about-text">${data.desc}</p>
      ${sectionsHtml}
      <div class="mt-4 text-center">
        <a href="#contact" class="btn btn-wwdc-gold wwdc-touchable modal-contact-btn">
          <i class="fa-solid fa-paper-plane"></i>
          <span>Discuss Similar Project</span>
        </a>
      </div>
    `;

    // Bind touch ripple to dynamically injected button
    const dynBtn = modalBody.querySelector('.modal-contact-btn');
    if (dynBtn) {
      dynBtn.addEventListener('pointerdown', (e) => createSpecularBloom(e, dynBtn));
      dynBtn.addEventListener('click', () => closeModal());
    }

    projectModal.classList.add('active');
    projectModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    if (!projectModal) return;
    projectModal.classList.remove('active');
    projectModal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  projectCards.forEach(card => {
    card.addEventListener('click', (e) => {
      const projectId = card.getAttribute('data-project');
      openModal(projectId);
    });
  });

  if (modalCloseBtn) {
    modalCloseBtn.addEventListener('click', closeModal);
  }

  if (projectModal) {
    projectModal.addEventListener('click', (e) => {
      if (e.target === projectModal) {
        closeModal();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && projectModal && projectModal.classList.contains('active')) {
      closeModal();
    }
  });

  /* ==========================================================================
     8. Copy to Clipboard Utility & Toast System
     ========================================================================== */
  const toastContainer = document.getElementById('toastContainer');

  function showToast(message) {
    if (!toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="fa-solid fa-circle-check text-apple-gold"></i><span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  const copyButtons = document.querySelectorAll('.copy-btn');
  copyButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const textToCopy = btn.getAttribute('data-copy');
      if (navigator.clipboard && textToCopy) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          showToast(`Copied "${textToCopy}" to clipboard!`);
        }).catch(() => {
          fallbackCopyText(textToCopy);
        });
      } else if (textToCopy) {
        fallbackCopyText(textToCopy);
      }
    });
  });

  function fallbackCopyText(text) {
    const tempInput = document.createElement('input');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    showToast(`Copied to clipboard!`);
  }

  /* ==========================================================================
     9. Mobile Navigation Toggle & Smooth Scrolling
     ========================================================================== */
  const menuToggle = document.getElementById('menuToggle');
  const navMenu = document.getElementById('navMenu');
  const navBackdrop = document.getElementById('navBackdrop');
  const navLinks = document.querySelectorAll('.nav-link');

  function toggleMenu() {
    const isOpen = navMenu.classList.contains('open');
    if (isOpen) {
      navMenu.classList.remove('open');
      navBackdrop.classList.remove('active');
      menuToggle.classList.remove('active');
      menuToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    } else {
      navMenu.classList.add('open');
      navBackdrop.classList.add('active');
      menuToggle.classList.add('active');
      menuToggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    }
  }

  if (menuToggle) {
    menuToggle.addEventListener('click', toggleMenu);
  }

  if (navBackdrop) {
    navBackdrop.addEventListener('click', toggleMenu);
  }

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (navMenu.classList.contains('open')) {
        toggleMenu();
      }
    });
  });

  // Active navigation highlight based on current section
  const sections = document.querySelectorAll('section[id]');
  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -70% 0px',
    threshold: 0
  };

  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(sec => navObserver.observe(sec));

  /* ==========================================================================
     10. Scroll-Triggered Entrance Animations
     ========================================================================== */
  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  const animObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animated');
        animObserver.unobserve(entry.target);
      }
    });
  }, {
    rootMargin: '0px 0px -40px 0px',
    threshold: 0.1
  });

  animatedElements.forEach(el => animObserver.observe(el));

  /* ==========================================================================
     11. Interactive Contact Form Validation
     ========================================================================== */
  const contactForm = document.getElementById('contactForm');
  const formSuccessAlert = document.getElementById('formSuccessAlert');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      let isValid = true;
      const nameInput = document.getElementById('name');
      const emailInput = document.getElementById('email');
      const subjectInput = document.getElementById('subject');
      const messageInput = document.getElementById('message');

      const nameError = document.getElementById('nameError');
      const emailError = document.getElementById('emailError');
      const subjectError = document.getElementById('subjectError');
      const messageError = document.getElementById('messageError');

      // Clear previous error messages
      [nameError, emailError, subjectError, messageError].forEach(err => {
        if (err) err.textContent = '';
      });

      // Name validation
      if (!nameInput.value.trim()) {
        nameError.textContent = 'Please enter your name.';
        isValid = false;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailInput.value.trim()) {
        emailError.textContent = 'Please enter your email address.';
        isValid = false;
      } else if (!emailRegex.test(emailInput.value.trim())) {
        emailError.textContent = 'Please enter a valid email address.';
        isValid = false;
      }

      // Subject validation
      if (!subjectInput.value.trim()) {
        subjectError.textContent = 'Please enter a subject.';
        isValid = false;
      }

      // Message validation
      if (!messageInput.value.trim()) {
        messageError.textContent = 'Please enter your message.';
        isValid = false;
      } else if (messageInput.value.trim().length < 10) {
        messageError.textContent = 'Message must be at least 10 characters long.';
        isValid = false;
      }

      if (isValid) {
        const submitBtn = document.getElementById('submitBtn');
        const originalText = submitBtn.innerHTML;

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> <span>Sending...</span>';

        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
          contactForm.reset();

          if (formSuccessAlert) {
            formSuccessAlert.classList.remove('hidden');
            setTimeout(() => {
              formSuccessAlert.classList.add('hidden');
            }, 6000);
          }

          showToast('Message sent successfully! Siraf will respond shortly.');
        }, 1000);
      }
    });
  }
});
